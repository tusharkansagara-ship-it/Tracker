# Course Follow-up Tracker — Working Prototype

## Run
Open `index.html` in a modern browser.

## Demo logins
Volunteer:
- email: volunteer@course.local
- password: vol123

Admin:
- email: admin@course.local
- password: admin123

## Included
- Volunteer/admin login
- Dashboard and priority queue
- Lead CRUD
- Volunteer assignment
- Automatic priority score
- Follow-up dates and history
- WhatsApp personalized message workflow
- Bulk selection and sequential opening of WhatsApp chats
- Message templates
- Browser localStorage persistence

## WhatsApp note
The prototype uses `https://wa.me/...` to open a prefilled WhatsApp message. It does not automate WhatsApp Web, scrape WhatsApp, or bypass WhatsApp Business/API policies. For production bulk messaging, connect an approved WhatsApp Business Platform provider/API and log delivery/opt-out status.

## Production database recommendation
PostgreSQL tables:
users, roles, leads, courses, batches, lead_assignments, followups, message_templates, outbound_messages, consent_records, audit_log.

Replace browser localStorage/auth with a backend API, hashed passwords, role-based access control, server-side validation, and encrypted secrets before deployment.
